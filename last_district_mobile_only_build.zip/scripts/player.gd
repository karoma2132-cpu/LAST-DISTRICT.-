extends CharacterBody3D

var car: CharacterBody3D
var in_car := false
var speed := 5.2
var gravity := 18.0
var camera_pivot: Node3D
var camera: Camera3D
var body_mesh: MeshInstance3D

func _ready() -> void:
    var shape := CollisionShape3D.new()
    var capsule := CapsuleShape3D.new()
    capsule.radius = 0.38
    capsule.height = 1.65
    shape.shape = capsule
    shape.position.y = 0.85
    add_child(shape)

    body_mesh = MeshInstance3D.new()
    var mesh := CapsuleMesh.new()
    mesh.radius = 0.38
    mesh.height = 1.65
    body_mesh.mesh = mesh
    body_mesh.position.y = 0.85
    var mat := StandardMaterial3D.new()
    mat.albedo_color = Color(0.12, 0.42, 0.82)
    body_mesh.material_override = mat
    add_child(body_mesh)

    camera_pivot = Node3D.new()
    camera_pivot.position = Vector3(0, 2.3, 0)
    add_child(camera_pivot)
    camera = Camera3D.new()
    camera.position = Vector3(0, 2.0, 6.5)
    camera.rotation_degrees.x = -12
    camera.current = true
    camera_pivot.add_child(camera)

func _physics_process(delta: float) -> void:
    if Input.is_action_just_pressed("interact"):
        _toggle_car()
    if in_car:
        global_position = car.global_position
        body_mesh.visible = false
        return
    body_mesh.visible = true
    var input_dir := Vector2(
        Input.get_action_strength("move_right") - Input.get_action_strength("move_left"),
        Input.get_action_strength("move_back") - Input.get_action_strength("move_forward")
    )
    var dir := Vector3(input_dir.x, 0, input_dir.y).normalized()
    if dir.length() > 0.1:
        velocity.x = dir.x * speed
        velocity.z = dir.z * speed
        rotation.y = atan2(-dir.x, -dir.z)
    else:
        velocity.x = move_toward(velocity.x, 0, speed * 5 * delta)
        velocity.z = move_toward(velocity.z, 0, speed * 5 * delta)
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = 0
    move_and_slide()

func _toggle_car() -> void:
    if car == null:
        return
    if not in_car and global_position.distance_to(car.global_position) < 3.2:
        in_car = true
        car.set_driving(true)
    elif in_car:
        in_car = false
        car.set_driving(false)
        global_position = car.global_position + car.global_transform.basis.x * 2.0 + Vector3.UP * 0.1
