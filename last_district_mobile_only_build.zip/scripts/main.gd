extends Node3D

const PLAYER_SCRIPT = preload("res://scripts/player.gd")
const CAR_SCRIPT = preload("res://scripts/car.gd")

var player
var car
var status_label: Label

func _ready() -> void:
    _setup_input()
    _build_world()
    car = CharacterBody3D.new()
    car.name = "TestCar"
    car.set_script(CAR_SCRIPT)
    add_child(car)
    car.global_position = Vector3(0, 0.55, -3)
    player = CharacterBody3D.new()
    player.name = "Player"
    player.set_script(PLAYER_SCRIPT)
    add_child(player)
    player.global_position = Vector3(2, 0.1, 1)
    player.car = car
    car.player = player
    _make_ui()


func _setup_input() -> void:
    _bind_key("move_forward", KEY_W)
    _bind_key("move_forward", KEY_UP)
    _bind_key("move_back", KEY_S)
    _bind_key("move_back", KEY_DOWN)
    _bind_key("move_left", KEY_A)
    _bind_key("move_left", KEY_LEFT)
    _bind_key("move_right", KEY_D)
    _bind_key("move_right", KEY_RIGHT)
    _bind_key("interact", KEY_E)

func _bind_key(action: String, keycode: Key) -> void:
    if not InputMap.has_action(action):
        InputMap.add_action(action)
    var event := InputEventKey.new()
    event.physical_keycode = keycode
    InputMap.action_add_event(action, event)

func _build_world() -> void:
    var env := WorldEnvironment.new()
    var environment := Environment.new()
    environment.background_mode = Environment.BG_SKY
    environment.sky = Sky.new()
    environment.ambient_light_source = Environment.AMBIENT_SOURCE_COLOR
    environment.ambient_light_color = Color(0.72, 0.78, 0.86)
    environment.ambient_light_energy = 0.7
    env.environment = environment
    add_child(env)

    var sun := DirectionalLight3D.new()
    sun.rotation_degrees = Vector3(-48, -25, 0)
    sun.light_energy = 1.1
    sun.shadow_enabled = true
    add_child(sun)

    _box("Ground", Vector3(0, -0.25, 0), Vector3(65, 0.5, 65), Color(0.20, 0.24, 0.22))
    _box("Road", Vector3(0, 0.015, 0), Vector3(11, 0.04, 65), Color(0.12, 0.13, 0.15))
    _box("CrossRoad", Vector3(0, 0.02, 0), Vector3(65, 0.04, 9), Color(0.12, 0.13, 0.15))
    for z in range(-28, 30, 5):
        _box("RoadMark", Vector3(0, 0.045, z), Vector3(0.18, 0.025, 2.2), Color(0.92, 0.88, 0.68))
    for x in [-5.2, 5.2]:
        _box("Sidewalk", Vector3(x, 0.12, 0), Vector3(1.3, 0.22, 65), Color(0.42, 0.43, 0.42))
    for z in [-5.0, 5.0]:
        _box("Sidewalk", Vector3(0, 0.12, z), Vector3(65, 0.22, 1.3), Color(0.42, 0.43, 0.42))

    var colors = [Color(0.48,0.50,0.54), Color(0.60,0.52,0.43), Color(0.39,0.48,0.53), Color(0.55,0.56,0.50)]
    var idx := 0
    for x in [-15, -23, 15, 23]:
        for z in [-17, 0, 17]:
            var h = 5.0 + float((idx * 7) % 8)
            _box("Building", Vector3(x, h/2.0, z), Vector3(6.0, h, 7.0), colors[idx % colors.size()])
            idx += 1
    # Low walls and props give the test area scale without heavy assets.
    _box("Warehouse", Vector3(15, 2.0, 27), Vector3(13, 4, 9), Color(0.34,0.38,0.42))
    _box("Container", Vector3(-15, 1.1, 27), Vector3(8, 2.2, 4), Color(0.45,0.25,0.18))

func _box(n: String, pos: Vector3, size: Vector3, color: Color) -> void:
    var body := StaticBody3D.new()
    body.name = n
    body.position = pos
    var mesh := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = size
    mesh.mesh = box
    var mat := StandardMaterial3D.new()
    mat.albedo_color = color
    mat.roughness = 0.88
    mesh.material_override = mat
    body.add_child(mesh)
    var shape := CollisionShape3D.new()
    var box_shape := BoxShape3D.new()
    box_shape.size = size
    shape.shape = box_shape
    body.add_child(shape)
    add_child(body)

func _make_ui() -> void:
    var layer := CanvasLayer.new()
    add_child(layer)
    var panel := PanelContainer.new()
    panel.position = Vector2(14, 14)
    panel.size = Vector2(330, 78)
    layer.add_child(panel)
    var label := Label.new()
    label.text = "LAST DISTRICT  |  TECH DEMO 0.1\nWASD / экранные кнопки — движение\nE — сесть / выйти из машины"
    panel.add_child(label)
    status_label = label

    var hint := Label.new()
    hint.text = "Цель: протестировать район, камеру и управление"
    hint.position = Vector2(14, 102)
    layer.add_child(hint)

    # Touch controls: buttons use action press/release so they work on Android.
    _touch_button(layer, "ВПЕРЁД", Vector2(18, 570), "move_forward")
    _touch_button(layer, "НАЗАД", Vector2(18, 630), "move_back")
    _touch_button(layer, "ВЛЕВО", Vector2(125, 630), "move_left")
    _touch_button(layer, "ВПРАВО", Vector2(232, 630), "move_right")
    _touch_button(layer, "ДЕЙСТВИЕ", Vector2(1030, 610), "interact")

func _touch_button(layer: CanvasLayer, caption: String, pos: Vector2, action: String) -> void:
    var button := Button.new()
    button.text = caption
    button.position = pos
    button.size = Vector2(98, 48)
    button.add_theme_font_size_override("font_size", 15)
    button.button_down.connect(func(): Input.action_press(action))
    button.button_up.connect(func(): Input.action_release(action))
    layer.add_child(button)
