extends CharacterBody3D

var player: CharacterBody3D
var driving := false
var acceleration := 13.0
var max_speed := 15.0
var reverse_speed := 6.0
var steering := 1.8
var current_speed := 0.0
var gravity := 18.0

func _ready() -> void:
    var chassis := MeshInstance3D.new()
    var box := BoxMesh.new()
    box.size = Vector3(2.0, 0.65, 3.8)
    chassis.mesh = box
    chassis.position.y = 0.8
    var paint := StandardMaterial3D.new()
    paint.albedo_color = Color(0.72, 0.12, 0.08)
    paint.metallic = 0.35
    paint.roughness = 0.32
    chassis.material_override = paint
    add_child(chassis)

    var cabin := MeshInstance3D.new()
    var cabin_mesh := BoxMesh.new()
    cabin_mesh.size = Vector3(1.55, 0.65, 1.8)
    cabin.mesh = cabin_mesh
    cabin.position = Vector3(0, 1.42, -0.25)
    var glass := StandardMaterial3D.new()
    glass.albedo_color = Color(0.12, 0.22, 0.29)
    glass.metallic = 0.25
    cabin.material_override = glass
    add_child(cabin)

    var collision := CollisionShape3D.new()
    var shape := BoxShape3D.new()
    shape.size = Vector3(2.0, 1.5, 3.8)
    collision.shape = shape
    collision.position.y = 0.8
    add_child(collision)

    for x in [-1.02, 1.02]:
        for z in [-1.2, 1.2]:
            var wheel := MeshInstance3D.new()
            var cylinder := CylinderMesh.new()
            cylinder.top_radius = 0.38
            cylinder.bottom_radius = 0.38
            cylinder.height = 0.22
            wheel.mesh = cylinder
            wheel.position = Vector3(x, 0.42, z)
            wheel.rotation_degrees.z = 90
            var rubber := StandardMaterial3D.new()
            rubber.albedo_color = Color(0.035,0.035,0.04)
            wheel.material_override = rubber
            add_child(wheel)

func set_driving(value: bool) -> void:
    driving = value
    if not driving:
        current_speed = 0.0

func _physics_process(delta: float) -> void:
    if driving:
        var throttle := Input.get_action_strength("move_forward") - Input.get_action_strength("move_back")
        var turn := Input.get_action_strength("move_right") - Input.get_action_strength("move_left")
        var limit := max_speed if throttle >= 0 else reverse_speed
        current_speed = move_toward(current_speed, throttle * limit, acceleration * delta)
        if abs(current_speed) > 0.2:
            rotation.y -= turn * steering * delta * sign(current_speed)
        var forward := -global_transform.basis.z
        velocity.x = forward.x * current_speed
        velocity.z = forward.z * current_speed
    else:
        velocity.x = move_toward(velocity.x, 0, 8 * delta)
        velocity.z = move_toward(velocity.z, 0, 8 * delta)
    if not is_on_floor():
        velocity.y -= gravity * delta
    else:
        velocity.y = 0
    move_and_slide()
    if get_slide_collision_count() > 0:
        current_speed *= 0.72
